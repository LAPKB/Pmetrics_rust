## qd

`qd` is a double-double implementation for extended precision floating point arithmetic.

based on Jack Poulson's [c++ implementation](https://gitlab.com/hodge_star/mantis/)

[![Documentation](https://docs.rs/qd/badge.svg)](https://docs.rs/qd)
[![Crate](https://img.shields.io/crates/v/qd.svg)](https://crates.io/crates/qd)
