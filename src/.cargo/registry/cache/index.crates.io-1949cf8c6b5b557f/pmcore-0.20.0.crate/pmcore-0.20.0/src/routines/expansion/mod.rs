pub mod adaptative_grid;
