use crate::IndexType;

pub struct SolverStatistics {
    pub niter: IndexType,
    pub nmaxiter: IndexType,
}
