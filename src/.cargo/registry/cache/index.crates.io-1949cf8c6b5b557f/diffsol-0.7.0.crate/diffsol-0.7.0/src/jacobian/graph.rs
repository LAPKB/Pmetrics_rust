pub type Graph = petgraph::graph::Graph<(), (), petgraph::Directed>;
