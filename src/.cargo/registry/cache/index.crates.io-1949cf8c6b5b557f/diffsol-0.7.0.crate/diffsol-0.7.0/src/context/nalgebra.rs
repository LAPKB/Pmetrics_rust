#[derive(Clone, Debug, PartialEq)]
pub struct NalgebraContext;

impl Default for NalgebraContext {
    fn default() -> Self {
        Self
    }
}
