#define MANGLE_HELPER(A, B) A##_##B
#define MANGLE(A, B) MANGLE_HELPER(A, B)