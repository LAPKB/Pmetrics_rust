// For backwards compatibility.
pub use crate::algo::maximum_flow::ford_fulkerson;
