use nalgebra::matrix;

fn main() {
    matrix![1, 2, 3;
            4, 5];
}