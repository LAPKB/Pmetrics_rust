`nano-gemm` is a library for small matrix multiplication.
