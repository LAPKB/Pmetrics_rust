`faer-rs` API for interoperability with external libraries.

See https://faer.veganb.tw/docs/dense-linalg/faer-ext/ for more details.
