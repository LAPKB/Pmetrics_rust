an experimental rayon-based threadpool that's optimized for repeated small tasks
